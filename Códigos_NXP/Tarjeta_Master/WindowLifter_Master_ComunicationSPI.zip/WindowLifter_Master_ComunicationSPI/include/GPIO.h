/*
 * GPIO.h
 *
 *  Created on: 05/11/2019
 *      Author: alabe
 */

#ifndef GPIO_H_
#define GPIO_H_

extern unsigned char GPIO_uc_GetRandomValue(void);
void PORT_v_InitializeSPI_Pins (void);

#endif /* GPIO_H_ */
