/*
 * ab_DataTypes.h
 *
 *  Created on: Nov 4, 2019
 *      Author: cvite
 */

#ifndef AB_DATATYPES_H_
#define AB_DATATYPES_H_

#define TRUE  1
#define FALSE 0

typedef enum
{
	NOK = 0,
	OK = 1
}e_Status;

#endif /* AB_DATATYPES_H_ */
